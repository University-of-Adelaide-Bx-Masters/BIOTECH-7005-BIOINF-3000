I keep all my bash scripts used in data processing in this folder
