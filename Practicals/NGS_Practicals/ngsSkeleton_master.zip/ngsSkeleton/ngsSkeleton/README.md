ngsSkeleton 

by @steveped Steve Pederson
