A possible directory structure for working with NGS data
