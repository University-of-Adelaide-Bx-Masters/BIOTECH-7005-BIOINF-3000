Sometimes aligners output helpful statistics and I save them here.
