Here is usually where I store my alignments in BAM format. I never never keep SAM files and neither should you.
