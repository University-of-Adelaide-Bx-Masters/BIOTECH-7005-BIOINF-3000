I sometimes run FastQC on my alignments and when I do, I write the reports to this directory
