When I run FastQC on my raw data, I write the reports to this directory
