This is usually where I place my raw data
