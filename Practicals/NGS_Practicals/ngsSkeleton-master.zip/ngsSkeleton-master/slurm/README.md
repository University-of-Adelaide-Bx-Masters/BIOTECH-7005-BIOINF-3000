I keep all my slurm output separately in this folder.
Note that I don't keep this output as part of my git repo though (see ./.gitignore), but that's just me.
