This is usually where I place my trimmed data
