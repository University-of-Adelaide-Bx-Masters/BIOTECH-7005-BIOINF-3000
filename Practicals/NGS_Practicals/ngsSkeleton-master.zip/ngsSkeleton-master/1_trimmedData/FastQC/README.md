When I run FastQC on my trimmed and filtered data, I write the reports to this directory
