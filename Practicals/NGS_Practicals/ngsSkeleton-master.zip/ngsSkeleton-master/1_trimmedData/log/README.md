When I remove adapters and discard low-quality reads I often save the log files (or output from stderr)  to this folder
